#!/bin/ksh

multigen  /afs/iitd.ac.in/user/v/vs/vst219509/ell734_mos_project/CLA/CCLFile_orig /afs/iitd.ac.in/user/v/vs/vst219509/ell734_mos_project/CLA/CCLFile
