set -e
set -x

rex -dp_comm_string 1,hertz1,42731 -V -m -pd -I# -tech /afs/iitd.ac.in/service/tools/public/asiclib/tsmc/L180/tsmc_180nm_oa/Assura/lvs_rcx -medge np_rnxwell,np_rpsub -no_cut -map p2elayermapfile -N NET -rP res.mod -mp mprexauHyQRq np_rmetal1::metal1_cut - rpolyCont_metal1_ppoly,1,t rpolyCont_metal1_poly,1,T rodCont_metal1_tpdiff,1,t rodCont_metal1_tndiff,1,t rVIA1,1,x - L1T0,1,I

rex -dp_comm_string 2,hertz1,42731 -V -m -pd -I# -tech /afs/iitd.ac.in/service/tools/public/asiclib/tsmc/L180/tsmc_180nm_oa/Assura/lvs_rcx -medge np_rnxwell,np_rpsub -no_cut -map p2elayermapfile -N NET -rP res.mod -mp mprexaeITEDq np_rpoly::poly_cut::-0.01 - pgate_MOS_21_mgvia,1,z ngate_MOS_3_mgvia,1,z rpoly_poly_gate1_not_IO1_butt_ovia,1 rpoly_gate1_not_IO1_ovia,1 rpolyCont_poly_ppoly,1,t rpolyCont_metal1_poly,1,x

rex -dp_comm_string 3,hertz1,42731 -V -m -pd -I# -tech /afs/iitd.ac.in/service/tools/public/asiclib/tsmc/L180/tsmc_180nm_oa/Assura/lvs_rcx -medge np_rnxwell,np_rpsub -no_cut -map p2elayermapfile -N NET -rP res.mod -mp mprexakX2d6q np_rmetal2::metal2_cut - rVIA2,1,x rVIA1,1,T - L2T0,1,I

rex -dp_comm_string 4,hertz1,42731 -V -m -pd -I# -tech /afs/iitd.ac.in/service/tools/public/asiclib/tsmc/L180/tsmc_180nm_oa/Assura/lvs_rcx -medge np_rnxwell,np_rpsub -no_cut -map p2elayermapfile -N NET -rP res.mod -mp mprexaNB1Nkr np_rmetal3::metal3_cut - rVIA3,1,x rVIA2,1,T

rex -dp_comm_string 5,hertz1,42731 -V -m -pd -I# -tech /afs/iitd.ac.in/service/tools/public/asiclib/tsmc/L180/tsmc_180nm_oa/Assura/lvs_rcx -medge np_rnxwell,np_rpsub -no_cut -map p2elayermapfile -N NET -rP res.mod -mp mprexaMbAzzr np_rmetal4::metal4_cut - rVIA3,1,T

rexmerge -V -N NET -medge np_rnxwell,np_rpsub -ls slab -n mprexaeITEDq,mprexauHyQRq,mprexakX2d6q,mprexaNB1Nkr,mprexaMbAzzr -b np_rpoly,np_rmetal1,np_rmetal2,np_rmetal3,np_rmetal4 -l ,L1T0,L2T0,, np_rpoly.res,np_rmetal1.res,np_rmetal2.res,np_rmetal3.res,np_rmetal4.res

